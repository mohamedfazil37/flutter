'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"flutter_bootstrap.js": "f46f7b32511361130ce99bebb71092bc",
"version.json": "6dbf088b372a5d984ddce897c8b854b4",
"index.html": "e9720ef0a243f0eb22555cf557105632",
"/": "e9720ef0a243f0eb22555cf557105632",
"main.dart.js": "dae16321a4d00aa629efe161e5314e42",
"flutter.js": "f31737fb005cd3a3c6bd9355efd33061",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"manifest.json": "ad1a496b55f340fff3fcc642d89f8c41",
"assets/AssetManifest.json": "fbbd82e84a485b29fe65853d959b7809",
"assets/NOTICES": "0c0742616017db1294da7e9a4612241c",
"assets/FontManifest.json": "2ccc807a5ffb57b24c844d6e7aaf2eca",
"assets/AssetManifest.bin.json": "2baa99326631074a5e9bca6cbc6ee70b",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "cc9457856ff4ac8c53e8e5159c2636f0",
"assets/packages/iconly/fonts/IconlyBold.ttf": "128714c5bf5b14842f735ecf709ca0d1",
"assets/packages/iconly/fonts/IconlyLight.ttf": "5f376412227e6f8450fe79aec1c2a800",
"assets/packages/iconly/fonts/IconlyBroken.ttf": "6fbd555150d4f77e91c345e125c4ecb6",
"assets/packages/font_awesome_flutter/lib/fonts/fa-solid-900.ttf": "fc83bba8cfc8f74af32b55d523317a05",
"assets/packages/font_awesome_flutter/lib/fonts/fa-regular-400.ttf": "aee4b48e91a104c5f0280d7dc1f14ece",
"assets/packages/font_awesome_flutter/lib/fonts/fa-brands-400.ttf": "4769f3245a24c1fa9965f113ea85ec2a",
"assets/packages/iconsax_flutter/fonts/FlutterIconsax.ttf": "83c878235f9c448928034fe5bcba1c8a",
"assets/packages/fluttertoast/assets/toastify.js": "56e2c9cedd97f10e7e5f1cebd85d53e3",
"assets/packages/fluttertoast/assets/toastify.css": "a85675050054f179444bc5ad70ffc635",
"assets/packages/flutter_dropzone_web/assets/flutter_dropzone.js": "dddc5c70148f56609c3fb6b29929388e",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/AssetManifest.bin": "fe0e1b3e4d3c5851adf9cd45e1bfaf8d",
"assets/fonts/MaterialIcons-Regular.otf": "39e02dbd9875896e0a6e655879ef8e4d",
"assets/assets/svg/Investment.svg": "c24244f2e1db25f17bdfd2e19924626a",
"assets/assets/svg/financial_transaction.svg": "f20f1d871c235edf3bf79475e697d933",
"assets/assets/svg/user_profile_circle.svg": "6ea31429c6e4d708e656e14b5e28d3ac",
"assets/assets/svg/add_people.svg": "e1ca4c240cf92a685aca867b2dd6ae9b",
"assets/assets/svg/pending_icon.svg": "d5f4e534c0cfafd2908bbdcf5ae0f5d0",
"assets/assets/svg/verification.svg": "9c5f5317a543ff4653d8d34d2d550cc6",
"assets/assets/svg/person_update.svg": "eb5310fdcfc561c72aed86afdc56d13f",
"assets/assets/svg/document.svg": "46b5349ac1f33585720edbcfc9dba12a",
"assets/assets/svg/refresh.svg": "129bb404c3ea66355a57f8cfa079bbde",
"assets/assets/svg/launch.svg": "ff5a7aa6d9d5a03f9095ca294e6a3fad",
"assets/assets/svg/non_financial_transaction.svg": "cb8a05cea5ab9b0afe98324622090168",
"assets/assets/svg/popup_button.svg": "0a5b6884c2ae990b3566f4fc928cd233",
"assets/assets/svg/registration.svg": "c4c110be7cf98094d5cb41a280918c86",
"assets/assets/svg/upwardsort.svg": "95d8ab93310476b083f4f1799d801b07",
"assets/assets/svg/fill_color.svg": "09cda2a2c63dbbd94906752f0bdd19e2",
"assets/assets/svg/up_arrow.svg": "fa2237ec3b6906d9dee883670f80819e",
"assets/assets/svg/verified_paper.svg": "59ad6f7b0402a8ac03ee4a6ec572fb0f",
"assets/assets/svg/transaction_value.svg": "9ef5336d834552aa05546a43c62c44ae",
"assets/assets/svg/downsort.svg": "e746fdf760c6091b619f68a4e29db307",
"assets/assets/images/IosApple.png": "4e4a93dda2f55dc715589dd8fb7f94fd",
"assets/assets/images/bank-transfer.png": "119137c1b1b15757030766ce1791de55",
"assets/assets/images/Android.png": "2586b4d38449f9390d6117b5b95f96ac",
"assets/assets/images/Investment.png": "9cbecca1e7cc0f5786e82534bdd63efd",
"assets/assets/images/bg_landing.jpg": "ec40c894439fcef4cc1aeda7bc63ad15",
"assets/assets/images/logo/db1.jpg": "5cbc0f4241b22915a168174ff0a5960f",
"assets/assets/images/logo/db2.png": "ab42cce1dfa9e22db5b68b79f5456cfb",
"assets/assets/images/logo/db.jpg": "5cbc0f4241b22915a168174ff0a5960f",
"assets/assets/images/logo/AppIcon.png": "ba94273c171ee32c46a4979404eafa41",
"assets/assets/images/logo/dcb_logo.png": "53a51b64f3bebb9cbbe89d3db203803f",
"assets/assets/images/upload.png": "b87dfb4163d9928e5f65e3577f1a4cc0",
"assets/assets/images/Pay.png": "57be43e026bc5ef06a58d00f7418c17c",
"assets/assets/images/paypal.png": "f1febb9eb36bba05c5ad403c7a34126f",
"assets/assets/images/Bill.png": "1e43a85b95d696a8b3e60a5067579bfd",
"assets/assets/responses/onboarding_count.json": "96ac5e433b0292c5dcd33492cb414cce",
"assets/assets/responses/kyc_count.json": "2cc15f13c4898d30c07c621c75552750",
"assets/assets/responses/login_count.json": "3a769a3c6ae8f43457a9cedc9f88d80b",
"assets/assets/responses/products.json": "e685de925c63920abc403951c551d2a3",
"assets/assets/responses/pending_req_count.json": "b6252dea101557a8fccdd2c4a51b969c",
"assets/assets/responses/financial_non_financial_count.json": "ade1041e9a67ee092dac39552ef302fb",
"assets/assets/fonts/Calibri/Calibri.ttf": "5d7c31b284ddb01fc1cbae0edc9ec210",
"assets/assets/fonts/roboto/Roboto-Medium.ttf": "68ea4734cf86bd544650aee05137d7bb",
"assets/assets/fonts/roboto/Roboto-Light.ttf": "881e150ab929e26d1f812c4342c15a7c",
"assets/assets/fonts/roboto/Roboto-Regular.ttf": "8a36205bd9b83e03af0591a004bc97f4",
"assets/assets/fonts/roboto/Roboto-Bold.ttf": "b8e42971dec8d49207a8c8e2b919a6ac",
"assets/assets/fonts/roboto/Roboto-Thin.ttf": "66209ae01f484e46679622dd607fcbc5",
"assets/assets/fonts/roboto/Roboto-Black.ttf": "d6a6f8878adb0d8e69f9fa2e0b622924",
"assets/assets/fonts/AdobeArabic/AdobeArabic-Regular.otf": "a0be3812ea6b2f862512ce5a0c3fdbce",
"assets/assets/themes/app_theme.json": "2431038ac0323cddcfafee4ee2c2f890",
"canvaskit/skwasm.js": "9fa2ffe90a40d062dd2343c7b84caf01",
"canvaskit/skwasm.js.symbols": "262f4827a1317abb59d71d6c587a93e2",
"canvaskit/canvaskit.js.symbols": "48c83a2ce573d9692e8d970e288d75f7",
"canvaskit/skwasm.wasm": "9f0c0c02b82a910d12ce0543ec130e60",
"canvaskit/chromium/canvaskit.js.symbols": "a012ed99ccba193cf96bb2643003f6fc",
"canvaskit/chromium/canvaskit.js": "87325e67bf77a9b483250e1fb1b54677",
"canvaskit/chromium/canvaskit.wasm": "b1ac05b29c127d86df4bcfbf50dd902a",
"canvaskit/canvaskit.js": "5fda3f1af7d6433d53b24083e2219fa0",
"canvaskit/canvaskit.wasm": "1f237a213d7370cf95f443d896176460",
"canvaskit/skwasm.worker.js": "bfb704a6c714a75da9ef320991e88b03"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
